"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchKbDocument = exports.s3Client = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
// Configure the S3 client to point to LocalStack
exports.s3Client = new client_s3_1.S3Client({
    region: "us-east-1",
    endpoint: "http://127.0.0.1:4566",
    forcePathStyle: true,
    credentials: {
        accessKeyId: "mock_access_key",
        secretAccessKey: "mock_secret_key",
    },
});
/**
 * Fetches a Knowledge Base document from the S3 bucket.
 */
const fetchKbDocument = async (docName) => {
    try {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: "omni-channel-kb-docs",
            Key: docName,
        });
        const response = await exports.s3Client.send(command);
        // Convert the S3 stream into a readable string
        const stream = response.Body;
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        const documentContent = Buffer.concat(chunks).toString("utf-8");
        return documentContent;
    }
    catch (error) {
        console.error(`[S3 Client] Failed to fetch document ${docName}:`, error);
        throw new Error("Failed to retrieve knowledge base document.");
    }
};
exports.fetchKbDocument = fetchKbDocument;
