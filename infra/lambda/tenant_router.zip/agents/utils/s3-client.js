"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadKbDocument = exports.fetchKbDocument = exports.s3Client = void 0;
exports.buildTenantS3Key = buildTenantS3Key;
const client_s3_1 = require("@aws-sdk/client-s3");
// Dynamic LocalStack vs AWS Cloud S3 configuration
const isLocal = process.env.IS_LOCAL !== "false";
const localstackEndpoint = process.env.LOCALSTACK_HOSTNAME
    ? `http://${process.env.LOCALSTACK_HOSTNAME}:4566`
    : "http://127.0.0.1:4566";
exports.s3Client = new client_s3_1.S3Client({
    region: process.env.AWS_REGION || "us-east-1",
    ...(isLocal && {
        endpoint: localstackEndpoint,
        forcePathStyle: true,
        credentials: {
            accessKeyId: "mock_access_key",
            secretAccessKey: "mock_secret_key",
        },
    }),
});
const KB_BUCKET_NAME = process.env.KB_BUCKET_NAME || "omni-channel-kb-docs";
/**
 * Helper: Builds an isolated S3 Object Key strictly partitioned by Tenant ID
 * Format: tenants/<tenantId>/<docName> or platform-kb/<tenantId>/<docName>
 */
function buildTenantS3Key(tenantId, docName) {
    if (!tenantId || !tenantId.trim()) {
        throw new Error("[S3 Isolation Error] tenantId is required to construct S3 Key.");
    }
    // Sanitize docName to prevent path traversal vulnerability (e.g., ../ or /)
    const sanitizedDocName = docName.replace(/^(\.\.[\/\\])+/, "").replace(/^\/+/, "");
    const cleanDocName = sanitizedDocName.startsWith(`tenants/${tenantId}/`)
        ? sanitizedDocName.replace(`tenants/${tenantId}/`, "")
        : sanitizedDocName;
    return `tenants/${tenantId.trim()}/${cleanDocName}`;
}
/**
 * Fetches a Knowledge Base document strictly scoped under the authenticated Tenant's S3 folder.
 */
const fetchKbDocument = async (context, docName) => {
    if (!context || !context.tenantId) {
        throw new Error("[S3 Isolation Guardrail] Missing authenticated TenantContext for RAG query.");
    }
    const isolatedKey = buildTenantS3Key(context.tenantId, docName);
    try {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: KB_BUCKET_NAME,
            Key: isolatedKey,
        });
        const response = await exports.s3Client.send(command);
        // Convert the S3 stream into a readable string
        const stream = response.Body;
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        return Buffer.concat(chunks).toString("utf-8");
    }
    catch (error) {
        // Local testing fallback if LocalStack S3 bucket object is not seeded
        console.warn(`[S3 Client Warning] S3 fetch skipped/offline for '${isolatedKey}'. Using mock KB document.`);
        return `
Issue: Slow Internet Connection
Resolution: Restart your router by unplugging the power cable for 30 seconds.
Issue: Router Power LED OFF
Resolution: Check if the power adapter is firmly plugged in.
    `.trim();
    }
};
exports.fetchKbDocument = fetchKbDocument;
/**
 * Uploads a Knowledge Base document directly into the authenticated Tenant's S3 folder.
 */
const uploadKbDocument = async (context, docName, content) => {
    if (!context || !context.tenantId) {
        throw new Error("[S3 Isolation Guardrail] Missing authenticated TenantContext for RAG upload.");
    }
    const isolatedKey = buildTenantS3Key(context.tenantId, docName);
    try {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: KB_BUCKET_NAME,
            Key: isolatedKey,
            Body: content,
            Metadata: {
                "tenant-id": context.tenantId,
                "uploaded-by": context.userId,
            },
        });
        await exports.s3Client.send(command);
        return isolatedKey;
    }
    catch (error) {
        console.warn(`[S3 Client Warning] S3 Upload skipped for local test: ${isolatedKey}`);
        return isolatedKey;
    }
};
exports.uploadKbDocument = uploadKbDocument;
