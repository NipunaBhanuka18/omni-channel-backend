import { S3Client } from "@aws-sdk/client-s3";
import { TenantContext } from "../../shared/types/tenant-context";
export declare const s3Client: S3Client;
/**
 * Helper: Builds an isolated S3 Object Key strictly partitioned by Tenant ID
 * Format: tenants/<tenantId>/<docName> or platform-kb/<tenantId>/<docName>
 */
export declare function buildTenantS3Key(tenantId: string, docName: string): string;
/**
 * Fetches a Knowledge Base document strictly scoped under the authenticated Tenant's S3 folder.
 */
export declare const fetchKbDocument: (context: TenantContext, docName: string) => Promise<string>;
/**
 * Uploads a Knowledge Base document directly into the authenticated Tenant's S3 folder.
 */
export declare const uploadKbDocument: (context: TenantContext, docName: string, content: string | Buffer) => Promise<string>;
