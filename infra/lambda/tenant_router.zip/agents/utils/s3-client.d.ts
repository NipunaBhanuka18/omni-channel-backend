import { S3Client } from "@aws-sdk/client-s3";
export declare const s3Client: S3Client;
/**
 * Fetches a Knowledge Base document from the S3 bucket.
 */
export declare const fetchKbDocument: (docName: string) => Promise<string>;
