"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.docClient = void 0;
exports.formatTenantPK = formatTenantPK;
exports.getTenantItem = getTenantItem;
exports.putTenantItem = putTenantItem;
exports.queryTenantItems = queryTenantItems;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Environment-aware LocalStack vs AWS Cloud configuration
const isLocal = process.env.IS_LOCAL !== "false";
const localstackEndpoint = process.env.LOCALSTACK_HOSTNAME
    ? `http://${process.env.LOCALSTACK_HOSTNAME}:4566`
    : "http://127.0.0.1:4566";
const client = new client_dynamodb_1.DynamoDBClient({
    region: process.env.AWS_REGION || "us-east-1",
    ...(isLocal && {
        endpoint: localstackEndpoint,
        credentials: {
            accessKeyId: "mock_access_key",
            secretAccessKey: "mock_secret_key",
        },
    }),
});
// Base DocumentClient export for low-level access if strictly required
exports.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
/**
 * TENANT ISOLATED HELPER: Formats a standard Tenant Partition Key (PK)
 * Format: TENANT#<tenantId>
 */
function formatTenantPK(tenantId) {
    if (!tenantId || !tenantId.trim()) {
        throw new Error("TenantIsolationError: tenantId cannot be empty or null.");
    }
    const cleanTenant = tenantId.trim();
    return cleanTenant.startsWith("TENANT#") ? cleanTenant : `TENANT#${cleanTenant}`;
}
/**
 * TENANT ISOLATED GET ITEM
 * Guarantees that the Partition Key (PK) is prefixed with the authenticated tenant's ID.
 */
async function getTenantItem(tableName, context, sortKey) {
    const partitionKey = formatTenantPK(context.tenantId);
    const keyObj = { PK: partitionKey };
    if (typeof sortKey === "string") {
        keyObj["SK"] = sortKey;
    }
    else {
        keyObj[sortKey.name] = sortKey.value;
    }
    const params = {
        TableName: tableName,
        Key: keyObj,
    };
    const response = await exports.docClient.send(new lib_dynamodb_1.GetCommand(params));
    return response.Item || null;
}
/**
 * TENANT ISOLATED PUT ITEM
 * Enforces that every item stored in DynamoDB carries PK: TENANT#<tenantId> and explicit tenantId field.
 */
async function putTenantItem(tableName, context, sortKeyOrItem, itemData) {
    const partitionKey = formatTenantPK(context.tenantId);
    let itemPayload = {};
    if (typeof sortKeyOrItem === "string") {
        itemPayload = {
            PK: partitionKey,
            SK: sortKeyOrItem,
            tenantId: context.tenantId,
            updatedAt: new Date().toISOString(),
            ...(itemData || {}),
        };
    }
    else {
        itemPayload = {
            ...sortKeyOrItem,
            PK: partitionKey,
            tenantId: context.tenantId,
            updatedAt: new Date().toISOString(),
        };
    }
    const params = {
        TableName: tableName,
        Item: itemPayload,
    };
    await exports.docClient.send(new lib_dynamodb_1.PutCommand(params));
}
/**
 * TENANT ISOLATED QUERY
 * Restricts query scans strictly to items matching PK = TENANT#<tenantId>.
 */
async function queryTenantItems(tableName, context, skPrefixOrCondition, expressionAttributeValues) {
    const partitionKey = formatTenantPK(context.tenantId);
    let keyConditionExpression = "PK = :pk";
    const attrValues = {
        ":pk": partitionKey,
        ...expressionAttributeValues,
    };
    if (skPrefixOrCondition) {
        if (skPrefixOrCondition.includes("=") || skPrefixOrCondition.includes("AND")) {
            keyConditionExpression = `PK = :pk AND ${skPrefixOrCondition}`;
        }
        else {
            keyConditionExpression += " AND begins_with(SK, :skPrefix)";
            attrValues[":skPrefix"] = skPrefixOrCondition;
        }
    }
    const params = {
        TableName: tableName,
        KeyConditionExpression: keyConditionExpression,
        ExpressionAttributeValues: attrValues,
    };
    const response = await exports.docClient.send(new lib_dynamodb_1.QueryCommand(params));
    return response.Items || [];
}
