"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.docClient = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
// Configure the client to point to LocalStack
const client = new client_dynamodb_1.DynamoDBClient({
    region: "us-east-1",
    endpoint: "http://127.0.0.1:4566", // Force IPv4
    credentials: {
        accessKeyId: "mock_access_key", // LocalStack doesn't care what these are
        secretAccessKey: "mock_secret_key",
    },
});
// Create a DocumentClient for easier automatic marshalling of TypeScript objects
exports.docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
