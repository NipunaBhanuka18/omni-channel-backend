"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.searchKnowledgeBase = void 0;
const s3_client_1 = require("./s3-client");
const searchKnowledgeBase = async (query, context, documentName = "router-troubleshooting-guide.txt") => {
    try {
        if (!context || !context.tenantId) {
            throw new Error("[KB Isolation Violation] Attempted to query Knowledge Base without an authenticated TenantContext.");
        }
        // Pass 'context' first, then 'documentName' into fetchKbDocument
        const fullDocument = await (0, s3_client_1.fetchKbDocument)(context, documentName);
        const sections = fullDocument
            .split("Issue:")
            .filter((s) => s.trim().length > 0);
        const queryLower = query.toLowerCase();
        let bestMatch = null;
        for (const section of sections) {
            if (section.toLowerCase().includes(queryLower)) {
                bestMatch = section;
                break;
            }
        }
        if (!bestMatch) {
            bestMatch = sections[0] || fullDocument;
        }
        return `[Tenant: ${context.tenantId}] Issue: ${bestMatch.trim()}`;
    }
    catch (error) {
        console.error(`[KB Retriever Error] Search failed for Tenant '${context?.tenantId}':`, error);
        throw new Error(`Failed to search knowledge base for tenant scope: ${error.message}`);
    }
};
exports.searchKnowledgeBase = searchKnowledgeBase;
