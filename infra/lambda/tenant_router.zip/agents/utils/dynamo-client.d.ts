import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { TenantContext } from "../../shared/types/tenant-context";
export declare const docClient: DynamoDBDocumentClient;
/**
 * TENANT ISOLATED HELPER: Formats a standard Tenant Partition Key (PK)
 * Format: TENANT#<tenantId>
 */
export declare function formatTenantPK(tenantId: string): string;
/**
 * TENANT ISOLATED GET ITEM
 * Guarantees that the Partition Key (PK) is prefixed with the authenticated tenant's ID.
 */
export declare function getTenantItem<T = Record<string, any>>(tableName: string, context: TenantContext, sortKey: string | {
    name: string;
    value: string;
}): Promise<T | null>;
/**
 * TENANT ISOLATED PUT ITEM
 * Enforces that every item stored in DynamoDB carries PK: TENANT#<tenantId> and explicit tenantId field.
 */
export declare function putTenantItem<T extends Record<string, any>>(tableName: string, context: TenantContext, sortKeyOrItem: string | T, itemData?: T): Promise<void>;
/**
 * TENANT ISOLATED QUERY
 * Restricts query scans strictly to items matching PK = TENANT#<tenantId>.
 */
export declare function queryTenantItems<T = Record<string, any>>(tableName: string, context: TenantContext, skPrefixOrCondition?: string, expressionAttributeValues?: Record<string, any>): Promise<T[]>;
