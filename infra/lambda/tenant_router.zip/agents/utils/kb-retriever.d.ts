import { TenantContext } from "../../shared/types/tenant-context";
export declare const searchKnowledgeBase: (query: string, context: TenantContext, documentName?: string) => Promise<string>;
