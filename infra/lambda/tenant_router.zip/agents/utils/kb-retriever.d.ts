/**
 * Mock Vector Index / RAG Retriever.
 * In production, this would convert the query into an embedding and query a Vector DB (like OpenSearch).
 * For local development, we fetch the doc and do a simple keyword match.
 */
export declare const searchKnowledgeBase: (query: string) => Promise<string>;
