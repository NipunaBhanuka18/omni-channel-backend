"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const permissions_1 = require("../../../shared/constants/permissions");
const kb_retriever_1 = require("../../utils/kb-retriever");
const handler = async (context, params) => {
    console.log(`[Support Specialist] Processing request for user ${context.userId}`);
    // Authorization Check
    if (!context.permissions.includes(permissions_1.PERMISSIONS.FAULTS_READ)) {
        return {
            success: false,
            error: {
                code: "FORBIDDEN",
                message: "User does not have permission to read support documents.",
                retryable: false,
            },
        };
    }
    // Search the knowledge base based on the user's params with Tenant Context
    try {
        const userQuery = params.query || "slow internet";
        // Pass userQuery and authenticated context into isolated KB retriever
        const searchResult = await (0, kb_retriever_1.searchKnowledgeBase)(userQuery, context);
        return {
            success: true,
            data: {
                source: "Vector Index (Mocked)",
                query: userQuery,
                result: searchResult,
            },
        };
    }
    catch (error) {
        return {
            success: false,
            error: {
                code: "KB_SEARCH_FAILED",
                message: `Failed to search knowledge base: ${error.message}`,
                retryable: true,
            },
        };
    }
};
exports.handler = handler;
