"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const permissions_1 = require("../../../shared/constants/permissions");
const usage_gateway_1 = require("../../gateway/usage-gateway");
const handler = async (context, params) => {
    console.log(`[Usage Specialist] Processing request for user ${context.userId}`);
    // 1. Authorization Check
    if (!context.permissions.includes(permissions_1.PERMISSIONS.USAGE_READ)) {
        return {
            success: false,
            error: {
                code: "FORBIDDEN",
                message: "User does not have permission to read usage information.",
                retryable: false,
            },
        };
    }
    // 2. Format the request for the Agent Gateway
    const gatewayRequest = {
        action: "check_usage",
        tenantId: context.tenantId,
        userId: context.userId,
        params: params,
    };
    // 3. Call the Agent Gateway
    return await (0, usage_gateway_1.handler)(gatewayRequest);
};
exports.handler = handler;
