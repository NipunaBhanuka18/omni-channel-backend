import { TenantContext } from "../../../shared/types/tenant-context";
import { AgentActionResponse } from "../../../shared/types/agent-action";
export declare const handler: (context: TenantContext, params: Record<string, any>) => Promise<AgentActionResponse>;
