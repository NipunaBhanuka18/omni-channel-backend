"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const permissions_1 = require("../../../shared/constants/permissions");
const billing_gateway_1 = require("../../gateway/billing-gateway");
const handler = async (context, params) => {
    console.log(`[Billing Specialist] Processing request for user ${context.userId}`);
    // 1. Authorization Check
    if (!context.permissions.includes(permissions_1.PERMISSIONS.BILLING_READ)) {
        return {
            success: false,
            error: {
                code: "FORBIDDEN",
                message: "User does not have permission to read billing information.",
                retryable: false,
            },
        };
    }
    // 2. Format the request for the Agent Gateway
    const gatewayRequest = {
        action: "check_balance", // In a dynamic system, this could be passed in from the Main Agent
        tenantId: context.tenantId,
        userId: context.userId,
        params: params,
    };
    // 3. Call the Agent Gateway
    return await (0, billing_gateway_1.handler)(gatewayRequest);
};
exports.handler = handler;
