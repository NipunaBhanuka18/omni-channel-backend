export declare const agentRegistry: Record<string, (context: any, params: any) => Promise<any>>;
