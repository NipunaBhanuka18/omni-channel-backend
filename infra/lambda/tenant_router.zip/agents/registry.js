"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentRegistry = void 0;
const handler_1 = require("./specialists/billing/handler");
// The Dynamic Agent Registry
// To add a new agent later, you just add a new entry here.
// The Main Agent code will never need to change.
exports.agentRegistry = {
    check_balance: handler_1.handler,
    pay_bill: handler_1.handler, // Billing handles both for now
};
