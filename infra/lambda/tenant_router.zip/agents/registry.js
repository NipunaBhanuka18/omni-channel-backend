"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentRegistry = void 0;
const handler_1 = require("./specialists/billing/handler");
const handler_2 = require("./specialists/usage/handler");
const handler_3 = require("./specialists/support/handler"); // <--- ADD THIS
// The Dynamic Agent Registry
exports.agentRegistry = {
    check_balance: handler_1.handler,
    pay_bill: handler_1.handler,
    check_usage: handler_2.handler,
    troubleshoot_router: handler_3.handler,
};
