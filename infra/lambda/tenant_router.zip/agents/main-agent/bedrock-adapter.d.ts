import { TenantContext } from "../../shared/types/tenant-context";
import { AgentActionResponse } from "../../shared/types/agent-action";
export interface AgentCoreSessionState {
    sessionId: string;
    tenantId: string;
    userId: string;
    channel: string;
    metadata: Record<string, any>;
}
/**
 * Amazon Bedrock AgentCore Supervisor Adapter
 * Provides microVM session state encapsulation and supervisor routing to specialized sub-agents.
 */
export declare class BedrockAgentCoreSupervisor {
    /**
     * Initializes an isolated session context for Bedrock AgentCore execution.
     */
    static createIsolatedSession(context: TenantContext): AgentCoreSessionState;
    /**
     * Supervisor Delegation Method: Routes intent to sub-agents (Billing, Usage, Support).
     */
    static delegateToSubAgent(intent: string, context: TenantContext, params: Record<string, any>): Promise<AgentActionResponse>;
}
