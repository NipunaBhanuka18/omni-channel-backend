"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const registry_1 = require("../registry");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_client_1 = require("../utils/dynamo-client");
const handler = async (event) => {
    const { context: tenantContext, intent, params } = event;
    console.log(`[Main Agent] Received intent '${intent}' for session ${tenantContext.sessionId}`);
    // 1. SAVE CONVERSATION STATE TO DYNAMODB
    try {
        await dynamo_client_1.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: "omni-channel-conversations",
            Item: {
                conversationId: tenantContext.conversationId,
                sessionId: tenantContext.sessionId,
                tenantId: tenantContext.tenantId,
                userId: tenantContext.userId,
                intent: intent,
                status: "ROUTED",
                timestamp: new Date().toISOString()
            }
        }));
        console.log(`[Main Agent] ✅ Saved conversation state to DynamoDB for conv: ${tenantContext.conversationId}`);
    }
    catch (dbError) {
        console.error("[Main Agent] ❌ Failed to save to DynamoDB:", dbError);
        // We don't want to fail the whole request if DB logging fails, so we continue
    }
    // 2. Dynamic Lookup: Find the agent that handles this intent
    const targetAgentHandler = registry_1.agentRegistry[intent];
    // 3. If no agent is registered for this intent, fail gracefully
    if (!targetAgentHandler) {
        return {
            success: false,
            error: {
                code: "NO_ROUTING_MATCH",
                message: `Main Agent could not route intent: ${intent}`,
                retryable: false
            }
        };
    }
    // 4. Execute the dynamic agent
    try {
        return await targetAgentHandler(tenantContext, params);
    }
    catch (error) {
        console.error("[Main Agent] Unhandled error during routing:", error);
        return {
            success: false,
            error: {
                code: "INTERNAL_ERROR",
                message: "An unexpected error occurred in the Main Agent.",
                retryable: false
            }
        };
    }
};
exports.handler = handler;
