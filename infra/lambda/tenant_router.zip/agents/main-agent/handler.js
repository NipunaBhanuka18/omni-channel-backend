"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const bedrock_adapter_1 = require("./bedrock-adapter");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_client_1 = require("../utils/dynamo-client");
const handler = async (event) => {
    const { context: tenantContext, intent, params } = event;
    console.log(`[Main Agent] Received intent '${intent}' for session ${tenantContext.sessionId}`);
    // 1. SAVE CONVERSATION STATE TO DYNAMODB
    try {
        await dynamo_client_1.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: "omni-channel-conversations",
            Item: {
                conversationId: tenantContext.conversationId,
                sessionId: tenantContext.sessionId,
                tenantId: tenantContext.tenantId,
                userId: tenantContext.userId,
                intent: intent,
                status: "ROUTED",
                timestamp: new Date().toISOString(),
            },
        }));
        console.log(`[Main Agent] ✅ Saved conversation state to DynamoDB for conv: ${tenantContext.conversationId}`);
    }
    catch (dbError) {
        console.error("[Main Agent] ❌ Failed to save to DynamoDB:", dbError);
    }
    // 2. Bedrock AgentCore Supervisor Delegation
    try {
        return await bedrock_adapter_1.BedrockAgentCoreSupervisor.delegateToSubAgent(intent, tenantContext, params);
    }
    catch (error) {
        console.error("[Main Agent] Unhandled error during Bedrock AgentCore supervisor routing:", error);
        return {
            success: false,
            error: {
                code: "INTERNAL_ERROR",
                message: "An unexpected error occurred in the Main Agent Bedrock Supervisor.",
                retryable: false,
            },
        };
    }
};
exports.handler = handler;
