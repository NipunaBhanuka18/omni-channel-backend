"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async (event) => {
    console.log(`[Usage Gateway] Received action: ${event.action} for tenant: ${event.tenantId}`);
    if (event.action === "check_usage") {
        // MOCK: Simulating a successful response from the existing SLT Usage API
        return {
            success: true,
            data: {
                packageName: "Unlimited Data Pro",
                dataUsedGb: 45.2,
                dataTotalGb: 100,
                voiceUsedMins: 150,
                voiceTotalMins: 500,
                renewalDate: "2026-09-01",
            },
        };
    }
    return {
        success: false,
        error: {
            code: "UNKNOWN_ACTION",
            message: `Action '${event.action}' is not supported by the usage gateway.`,
            retryable: false,
        },
    };
};
exports.handler = handler;
