import { AgentActionRequest, AgentActionResponse } from "../../shared/types/agent-action";
export declare const handler: (event: AgentActionRequest) => Promise<AgentActionResponse>;
