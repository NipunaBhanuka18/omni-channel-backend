"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const dynamo_client_1 = require("../agents/utils/dynamo-client");
const handoffTables = [
    {
        tableName: "omni-channel-agent-presence",
        pk: "tenantId",
        sk: "agentId",
    },
    {
        tableName: "omni-channel-chat-sessions",
        pk: "sessionId",
    },
    {
        tableName: "omni-channel-missed-handoffs",
        pk: "tenantId",
        sk: "missedId",
    },
];
async function createTableIfNotExists(spec) {
    const keySchema = [{ AttributeName: spec.pk, KeyType: "HASH" }];
    const attributeDefinitions = [{ AttributeName: spec.pk, AttributeType: "S" }];
    if (spec.sk) {
        keySchema.push({ AttributeName: spec.sk, KeyType: "RANGE" });
        attributeDefinitions.push({ AttributeName: spec.sk, AttributeType: "S" });
    }
    const command = new client_dynamodb_1.CreateTableCommand({
        TableName: spec.tableName,
        KeySchema: keySchema,
        AttributeDefinitions: attributeDefinitions,
        BillingMode: "PAY_PER_REQUEST",
    });
    try {
        const response = await dynamo_client_1.docClient.send(command);
        console.log(`✅ Table created: ${response.TableDescription?.TableName}`);
    }
    catch (err) {
        if (err.name === "ResourceInUseException") {
            console.log(`ℹ️ Table already exists: ${spec.tableName}`);
        }
        else {
            console.error(`❌ Error creating table ${spec.tableName}:`, err?.message || err);
        }
    }
}
async function main() {
    console.log("=== Provisioning Live Agent Handoff & Presence Tables ===");
    for (const table of handoffTables) {
        await createTableIfNotExists(table);
    }
    console.log("✅ Handoff table provisioning routine complete.");
}
main();
