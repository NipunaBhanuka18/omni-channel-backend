"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const handler_1 = require("../agents/main-agent/handler");
const permissions_1 = require("../shared/constants/permissions");
const mockContext = {
    tenantId: "tenant-001",
    userId: "user-123",
    role: "staff",
    permissions: [
        permissions_1.PERMISSIONS.BILLING_READ,
        permissions_1.PERMISSIONS.USAGE_READ,
        permissions_1.PERMISSIONS.FAULTS_READ,
    ], // User HAS faults:read
    channel: "web",
    sessionId: "session-999",
    conversationId: "conv-555",
};
async function runTest() {
    console.log("--- Starting Support Agent Test ---");
    const result = await (0, handler_1.handler)({
        context: mockContext,
        intent: "troubleshoot_router", // Testing the NEW intent
        params: { query: "slow internet" },
    });
    console.log("\n--- Result ---");
    if (result.success && result.data?.source === "Vector Index (Mocked)") {
        console.log("✅ SUCCESS: Dynamic routing to Support Agent worked! It queried the mock Vector Index.");
    }
    else {
        console.log("❌ ERROR: Did not route to support agent correctly.");
        console.log(JSON.stringify(result, null, 2));
    }
}
runTest();
