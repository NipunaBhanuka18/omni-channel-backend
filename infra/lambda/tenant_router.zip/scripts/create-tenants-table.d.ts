export interface TenantRecord {
    tenantId: string;
    companyName: string;
    companySlug: string;
    adminEmail: string;
    status: "active" | "suspended" | "pending";
    planTier: "starter" | "pro" | "enterprise";
    createdAt: string;
    updatedAt: string;
    config?: {
        themeColor?: string;
        logoUrl?: string;
        allowedOrigins?: string[];
    };
}
export interface TenantAgentRecord {
    tenantId: string;
    agentId: string;
    agentName: string;
    specialist: "supervisor" | "support" | "billing" | "usage" | "leads";
    status: "active" | "inactive";
    welcomeMessage: string;
    createdAt: string;
}
export interface TenantToolRecord {
    tenantId: string;
    toolId: string;
    toolName: string;
    type: "openapi" | "form" | "mcp";
    endpointOrSchema: string;
    status: "enabled" | "disabled";
}
export declare const inMemoryTenants: Map<string, TenantRecord>;
export declare const inMemoryAgents: Map<string, TenantAgentRecord>;
export declare const inMemoryTools: Map<string, TenantToolRecord>;
export declare function provisionTenantResources(): Promise<boolean>;
