"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const s3_client_1 = require("../agents/utils/s3-client");
async function runTest() {
    console.log("--- Starting S3 Fetch Test ---");
    try {
        const content = await (0, s3_client_1.fetchKbDocument)("router-troubleshooting-guide.txt");
        console.log("\n✅ SUCCESS: Fetched document from S3!");
        console.log("\n--- Document Content ---");
        console.log(content);
        console.log("------------------------\n");
    }
    catch (error) {
        console.error("\n❌ ERROR: Failed to fetch from S3.", error);
    }
}
runTest();
