"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inMemoryTools = exports.inMemoryAgents = exports.inMemoryTenants = void 0;
exports.provisionTenantResources = provisionTenantResources;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const rawClient = new client_dynamodb_1.DynamoDBClient({
    region: "us-east-1",
    endpoint: "http://127.0.0.1:4566",
    credentials: {
        accessKeyId: "mock_access_key",
        secretAccessKey: "mock_secret_key",
    },
});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(rawClient);
// In-Memory Seed Storage for offline testing & immediate verification
exports.inMemoryTenants = new Map();
exports.inMemoryAgents = new Map();
exports.inMemoryTools = new Map();
const tablesToCreate = [
    {
        TableName: "omni-channel-tenants",
        KeySchema: [{ AttributeName: "tenantId", KeyType: "HASH" }],
        AttributeDefinitions: [
            { AttributeName: "tenantId", AttributeType: "S" },
        ],
        BillingMode: "PAY_PER_REQUEST",
    },
    {
        TableName: "omni-channel-agents",
        KeySchema: [
            { AttributeName: "tenantId", KeyType: "HASH" },
            { AttributeName: "agentId", KeyType: "RANGE" },
        ],
        AttributeDefinitions: [
            { AttributeName: "tenantId", AttributeType: "S" },
            { AttributeName: "agentId", AttributeType: "S" },
        ],
        BillingMode: "PAY_PER_REQUEST",
    },
    {
        TableName: "omni-channel-tools",
        KeySchema: [
            { AttributeName: "tenantId", KeyType: "HASH" },
            { AttributeName: "toolId", KeyType: "RANGE" },
        ],
        AttributeDefinitions: [
            { AttributeName: "tenantId", AttributeType: "S" },
            { AttributeName: "toolId", AttributeType: "S" },
        ],
        BillingMode: "PAY_PER_REQUEST",
    },
];
const baselineTenants = [
    {
        tenantId: "slt",
        companyName: "Sri Lanka Telecom (SLT-Mobitel)",
        companySlug: "slt",
        adminEmail: "admin@slt.lk",
        status: "active",
        planTier: "enterprise",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        config: {
            themeColor: "#005EB8",
            allowedOrigins: ["http://localhost:3000", "https://chat.slt.lk"],
        },
    },
    {
        tenantId: "tenant-test-123",
        companyName: "Acme Test Corp",
        companySlug: "acme-test",
        adminEmail: "admin@acmetest.io",
        status: "active",
        planTier: "starter",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        config: {
            themeColor: "#10B981",
        },
    },
];
const baselineAgents = [
    {
        tenantId: "slt",
        agentId: "agent-slt-support-01",
        agentName: "SLT Broadband Technical Specialist",
        specialist: "support",
        status: "active",
        welcomeMessage: "Hello! I am SLT Broadband Support Bot. How can I assist you with your connection today?",
        createdAt: new Date().toISOString(),
    },
    {
        tenantId: "slt",
        agentId: "agent-slt-billing-01",
        agentName: "SLT Billing & Accounts Assistant",
        specialist: "billing",
        status: "active",
        welcomeMessage: "Welcome to SLT Billing. You can check your balance or pay your monthly bill here.",
        createdAt: new Date().toISOString(),
    },
    {
        tenantId: "tenant-test-123",
        agentId: "agent-acme-support-01",
        agentName: "Acme General Customer Bot",
        specialist: "support",
        status: "active",
        welcomeMessage: "Welcome to Acme Corp! How can we help you today?",
        createdAt: new Date().toISOString(),
    },
];
const baselineTools = [
    {
        tenantId: "slt",
        toolId: "tool-check-balance",
        toolName: "SLT Check Account Balance API",
        type: "openapi",
        endpointOrSchema: "https://api.slt.lk/v1/billing/balance",
        status: "enabled",
    },
    {
        tenantId: "slt",
        toolId: "tool-report-fault",
        toolName: "SLT Broadband Fault Report Form",
        type: "form",
        endpointOrSchema: "form_broadband_fault_v1",
        status: "enabled",
    },
];
async function provisionTenantResources() {
    console.log("🚀 [Tenant Provisioning] Initializing Multi-Tenant DynamoDB tables...");
    // Seed into memory first
    for (const t of baselineTenants)
        exports.inMemoryTenants.set(t.tenantId, t);
    for (const a of baselineAgents)
        exports.inMemoryAgents.set(`${a.tenantId}#${a.agentId}`, a);
    for (const tool of baselineTools)
        exports.inMemoryTools.set(`${tool.tenantId}#${tool.toolId}`, tool);
    let localstackOnline = true;
    for (const tableDef of tablesToCreate) {
        try {
            await rawClient.send(new client_dynamodb_1.CreateTableCommand(tableDef));
            console.log(`✅ [DynamoDB] Created table '${tableDef.TableName}'`);
        }
        catch (err) {
            if (err instanceof client_dynamodb_1.ResourceInUseException || err.name === "ResourceInUseException") {
                console.log(`ℹ️ [DynamoDB] Table '${tableDef.TableName}' already exists.`);
            }
            else {
                console.warn(`⚠️ [DynamoDB Warning] Could not reach LocalStack for '${tableDef.TableName}' (${err.message}). Using in-memory store fallback.`);
                localstackOnline = false;
                break;
            }
        }
    }
    if (localstackOnline) {
        console.log("🌱 [Seed Data] Writing baseline tenants, agents, and tools to DynamoDB...");
        try {
            for (const t of baselineTenants) {
                await docClient.send(new lib_dynamodb_1.PutCommand({
                    TableName: "omni-channel-tenants",
                    Item: t,
                }));
            }
            for (const a of baselineAgents) {
                await docClient.send(new lib_dynamodb_1.PutCommand({
                    TableName: "omni-channel-agents",
                    Item: a,
                }));
            }
            for (const tool of baselineTools) {
                await docClient.send(new lib_dynamodb_1.PutCommand({
                    TableName: "omni-channel-tools",
                    Item: tool,
                }));
            }
            console.log("✅ [Seed Data] Successfully seeded baseline tenant records in DynamoDB!");
        }
        catch (seedErr) {
            console.warn(`⚠️ [Seed Data Warning] Failed to seed DynamoDB tables: ${seedErr.message}`);
        }
    }
    else {
        console.log("✅ [Seed Data] Baseline records seeded in-memory fallback successfully!");
    }
    return true;
}
// Auto-run if executed directly via tsx
if (process.argv[1]?.includes("create-tenants-table")) {
    provisionTenantResources()
        .then(() => process.exit(0))
        .catch((err) => {
        console.error("❌ Fatal error provisioning tenant resources:", err);
        process.exit(1);
    });
}
