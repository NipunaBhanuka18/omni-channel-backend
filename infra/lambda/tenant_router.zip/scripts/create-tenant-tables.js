"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const dynamo_client_1 = require("../agents/utils/dynamo-client");
async function createTenantTables() {
    const tables = [
        {
            TableName: "omni-channel-tenants",
            BillingMode: "PAY_PER_REQUEST",
            KeySchema: [
                { AttributeName: "PK", KeyType: "HASH" },
                { AttributeName: "SK", KeyType: "RANGE" },
            ],
            AttributeDefinitions: [
                { AttributeName: "PK", AttributeType: "S" },
                { AttributeName: "SK", AttributeType: "S" },
            ],
        },
        {
            TableName: "omni-channel-agents",
            BillingMode: "PAY_PER_REQUEST",
            KeySchema: [
                { AttributeName: "PK", KeyType: "HASH" },
                { AttributeName: "SK", KeyType: "RANGE" },
            ],
            AttributeDefinitions: [
                { AttributeName: "PK", AttributeType: "S" },
                { AttributeName: "SK", AttributeType: "S" },
            ],
        },
    ];
    for (const tableInput of tables) {
        try {
            await dynamo_client_1.docClient.send(new client_dynamodb_1.CreateTableCommand(tableInput));
            console.log(` Table created successfully: ${tableInput.TableName}`);
        }
        catch (err) {
            if (err.name === "ResourceInUseException") {
                console.log(`ℹ Table already exists: ${tableInput.TableName}`);
            }
            else {
                console.error(` Error creating table ${tableInput.TableName}:`, err.message);
            }
        }
    }
}
createTenantTables();
