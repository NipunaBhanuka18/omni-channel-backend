"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const handler_1 = require("../agents/main-agent/handler");
const permissions_1 = require("../shared/constants/permissions");
// 1. Mock the TenantContext
const mockContext = {
    tenantId: "tenant-001",
    userId: "user-123",
    role: "staff",
    permissions: [permissions_1.PERMISSIONS.BILLING_READ, permissions_1.PERMISSIONS.USAGE_READ], // User HAS usage:read
    channel: "web",
    sessionId: "session-999",
    conversationId: "conv-555",
};
// 2. Run the test
async function runTest() {
    console.log("--- Starting Usage Agent Test ---");
    const result = await (0, handler_1.handler)({
        context: mockContext,
        intent: "check_usage", // We are testing the NEW intent
        params: {},
    });
    console.log("\n--- Result ---");
    console.log(JSON.stringify(result, null, 2));
    if (result.success && result.data?.packageName) {
        console.log("\n✅ SUCCESS: Dynamic routing to Usage Agent worked!");
    }
    else {
        console.log("\n❌ ERROR: Did not route to usage agent correctly.");
    }
}
runTest();
