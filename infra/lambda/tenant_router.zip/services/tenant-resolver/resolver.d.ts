import { TenantContext } from "../../shared/types/tenant-context";
import { AgentActionResponse } from "../../shared/types/agent-action";
export interface TenantResolverResult {
    success: boolean;
    context?: TenantContext;
    error?: AgentActionResponse["error"];
}
/**
 * Resolves incoming HTTP request headers into a strictly typed TenantContext object.
 *
 * @param headers Map of incoming HTTP headers (case-insensitive keys supported)
 * @returns TenantResolverResult containing either the resolved TenantContext or a structured AgentActionResponse error.
 */
export declare function resolveTenantContext(headers: Record<string, string | undefined>): TenantResolverResult;
