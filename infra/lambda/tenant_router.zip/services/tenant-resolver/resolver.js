"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveTenantContext = resolveTenantContext;
const mock_jwt_validator_1 = require("./mock-jwt-validator");
const crypto_1 = require("crypto");
const ALLOWED_CHANNELS = [
    "web",
    "whatsapp",
    "sms",
    "messenger",
];
/**
 * Resolves incoming HTTP request headers into a strictly typed TenantContext object.
 * Enforces Zero-Trust tenant validation and spoofing detection (Member 2 Scope).
 *
 * @param headers Map of incoming HTTP headers (case-insensitive keys supported)
 * @returns TenantResolverResult containing either the resolved TenantContext or a structured AgentActionResponse error.
 */
function resolveTenantContext(headers) {
    const normalizedHeaders = {};
    for (const [key, value] of Object.entries(headers)) {
        if (value !== undefined) {
            normalizedHeaders[key.toLowerCase()] = value;
        }
    }
    const authorizationHeader = normalizedHeaders["authorization"];
    const tenantIdHeader = normalizedHeaders["x-tenant-id"];
    const channelHeader = normalizedHeaders["x-channel"];
    const sessionIdHeader = normalizedHeaders["x-session-id"];
    const conversationIdHeader = normalizedHeaders["x-conversation-id"];
    // Validate missing Authorization header
    if (!authorizationHeader || !authorizationHeader.trim()) {
        return {
            success: false,
            error: {
                code: "UNAUTHORIZED",
                message: "Missing or empty Authorization header. Expected format: 'Bearer <token>'",
                retryable: false,
                details: { requiredHeader: "Authorization" },
            },
        };
    }
    // Validate missing x-tenant-id header
    if (!tenantIdHeader || !tenantIdHeader.trim()) {
        return {
            success: false,
            error: {
                code: "BAD_REQUEST",
                message: "Missing or empty x-tenant-id header",
                retryable: false,
                details: { requiredHeader: "x-tenant-id" },
            },
        };
    }
    // Decode token via JWT validator
    let decodedClaims;
    try {
        decodedClaims = (0, mock_jwt_validator_1.decodeMockAzureJwt)(authorizationHeader);
    }
    catch (err) {
        return {
            success: false,
            error: {
                code: "UNAUTHORIZED",
                message: `Invalid or malformed Authorization token: ${err.message}`,
                retryable: false,
            },
        };
    }
    // STRICT TENANT ISOLATION CHECK (ZERO-TRUST SPOOFING GUARD)
    const tokenTenantId = decodedClaims.tenantId;
    const requestedTenantId = tenantIdHeader.trim();
    if (tokenTenantId && tokenTenantId !== requestedTenantId) {
        return {
            success: false,
            error: {
                code: "FORBIDDEN",
                message: `Tenant ID spoofing detected. Tenant mismatch error: Token tenant '${tokenTenantId}' does not match requested header tenant '${requestedTenantId}'.`,
                retryable: false,
                details: { tokenTenantId, requestedTenantId },
            },
        };
    }
    const tenantId = tokenTenantId || requestedTenantId;
    // Resolve Channel
    let channel = "web";
    if (channelHeader &&
        ALLOWED_CHANNELS.includes(channelHeader.toLowerCase())) {
        channel = channelHeader.toLowerCase();
    }
    // Resolve Session ID
    const sessionId = sessionIdHeader && sessionIdHeader.trim()
        ? sessionIdHeader.trim()
        : `sess-${(0, crypto_1.randomUUID)()}`;
    // Resolve Conversation ID
    const conversationId = conversationIdHeader && conversationIdHeader.trim()
        ? conversationIdHeader.trim()
        : `conv-${(0, crypto_1.randomUUID)()}`;
    const context = {
        tenantId,
        userId: decodedClaims.userId || "dev-user-001",
        role: decodedClaims.role || "staff",
        permissions: decodedClaims.permissions || [
            "billing:read",
            "usage:read",
            "faults:read",
        ],
        channel,
        sessionId,
        conversationId,
    };
    return {
        success: true,
        context,
    };
}
