import { TenantContext } from "../../shared/types/tenant-context";
export interface MockAzureJwtClaims {
    sub?: string;
    oid?: string;
    tid?: string;
    name?: string;
    preferred_username?: string;
    "custom:tenant_id"?: string;
    tenant_id?: string;
    roles?: string[];
    aud?: string;
    iss?: string;
}
/**
 * Parses and extracts tenant context claims from an unverified mock Azure AD / Cognito JWT token.
 *
 * @param authorizationHeader The incoming Authorization HTTP header (e.g. "Bearer <token>")
 * @returns Parsed TenantContext
 */
export declare function decodeMockAzureJwt(authorizationHeader?: string): Partial<TenantContext>;
