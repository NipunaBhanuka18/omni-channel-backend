export interface RegisterTenantInput {
    companyName: string;
    companySlug: string;
    adminEmail: string;
    planTier?: "starter" | "pro" | "enterprise";
    themeColor?: string;
    allowedOrigins?: string[];
}
export interface RegisterTenantResult {
    success: boolean;
    tenantId: string;
    companyName: string;
    companySlug: string;
    adminEmail: string;
    status: "active" | "pending";
    planTier: "starter" | "pro" | "enterprise";
    defaultAgent: {
        agentId: string;
        agentName: string;
        specialist: string;
    };
    credentials: {
        username: string;
        temporaryPassword: string;
        userPoolId: string;
        loginUrl: string;
    };
    storage: {
        s3Prefix: string;
        welcomeDocKey: string;
    };
    message: string;
}
/**
 * Onboards a new company onto the Multi-Tenant Platform.
 * Enforces strict tenant partitioning across DynamoDB, S3, and Cognito credentials.
 */
export declare function registerTenant(input: RegisterTenantInput): Promise<RegisterTenantResult>;
/**
 * Lambda / HTTP Gateway handler for POST /tenants/register
 */
export declare function handleRegisterTenantRequest(event: {
    httpMethod?: string;
    body?: string | Record<string, any>;
}): Promise<{
    statusCode: number;
    headers: Record<string, string>;
    body: string;
}>;
