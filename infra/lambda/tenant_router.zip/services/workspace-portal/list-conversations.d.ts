/**
 * Workspace Portal API: List all recent conversations.
 * (In a real app, this would be paginated and filtered by tenantId)
 */
export declare const handler: () => Promise<{
    success: boolean;
    data: Record<string, any>[] | undefined;
    error?: undefined;
} | {
    data?: undefined;
    success: boolean;
    error: {
        code: string;
        message: string;
        retryable: boolean;
    };
}>;
