/**
 * Workspace Portal API: Upload a new Knowledge Base document to S3.
 */
export declare const handler: (event: {
    fileName: string;
    content: string;
}) => Promise<{
    success: boolean;
    data: {
        message: string;
    };
    error?: undefined;
} | {
    data?: undefined;
    success: boolean;
    error: {
        code: string;
        message: string;
        retryable: boolean;
    };
}>;
