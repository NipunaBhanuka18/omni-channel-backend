"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_client_1 = require("../../agents/utils/s3-client");
/**
 * Workspace Portal API: Upload a new Knowledge Base document to S3.
 */
const handler = async (event) => {
    console.log(`[Workspace Portal] Uploading document: ${event.fileName}`);
    try {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: "omni-channel-kb-docs",
            Key: event.fileName,
            Body: event.content,
            ContentType: "text/plain",
        });
        await s3_client_1.s3Client.send(command);
        console.log("[Workspace Portal] ✅ Document uploaded successfully.");
        return {
            success: true,
            data: {
                message: `Document '${event.fileName}' uploaded to KB.`,
            },
        };
    }
    catch (error) {
        console.error("[Workspace Portal] ❌ Failed to upload document:", error);
        return {
            success: false,
            error: {
                code: "S3_UPLOAD_FAILED",
                message: "Could not upload document to S3.",
                retryable: true,
            },
        };
    }
};
exports.handler = handler;
