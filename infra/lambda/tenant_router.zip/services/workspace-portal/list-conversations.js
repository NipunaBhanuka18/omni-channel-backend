"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const dynamo_client_1 = require("../../agents/utils/dynamo-client");
/**
 * Workspace Portal API: List all recent conversations.
 * (In a real app, this would be paginated and filtered by tenantId)
 */
const handler = async () => {
    console.log("[Workspace Portal] Fetching all conversations...");
    try {
        const command = new lib_dynamodb_1.ScanCommand({
            TableName: "omni-channel-conversations",
            Limit: 10, // Just grab the latest 10 for now
        });
        const response = await dynamo_client_1.docClient.send(command);
        console.log("[Workspace Portal] ✅ Successfully fetched conversations.");
        return {
            success: true,
            data: response.Items,
        };
    }
    catch (error) {
        console.error("[Workspace Portal] ❌ Failed to fetch conversations:", error);
        return {
            success: false,
            error: {
                code: "DB_SCAN_FAILED",
                message: "Could not retrieve conversations from the database.",
                retryable: false,
            },
        };
    }
};
exports.handler = handler;
