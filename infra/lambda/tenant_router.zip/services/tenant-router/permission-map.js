"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.INTENT_PERMISSION_MAP = void 0;
exports.getRequiredPermissionForIntent = getRequiredPermissionForIntent;
const permissions_1 = require("../../shared/constants/permissions");
/**
 * ==============================================================================
 * Intent-to-Permission Mapping (RBAC Matrix)
 * ==============================================================================
 * Maps business intents to required fine-grained permissions.
 * Structure this map so adding a new intent -> permission mapping is a single-line addition.
 */
exports.INTENT_PERMISSION_MAP = {
    check_balance: permissions_1.PERMISSIONS.BILLING_READ,
    pay_bill: permissions_1.PERMISSIONS.BILLING_PURCHASE,
    check_usage: permissions_1.PERMISSIONS.USAGE_READ,
    troubleshoot_router: permissions_1.PERMISSIONS.FAULTS_READ,
};
/**
 * Resolves the required permission for a given business intent.
 *
 * SECURITY DESIGN: FAIL CLOSED
 * If an intent is not explicitly mapped in INTENT_PERMISSION_MAP, this function returns undefined.
 * Callers MUST treat undefined as access denied (fail closed) to ensure any future/unmapped intents
 * are not silently permissive or permitted without explicit security authorization.
 *
 * @param intent The business intent string (e.g. "check_balance")
 * @returns The required permission string or undefined if unmapped
 */
function getRequiredPermissionForIntent(intent) {
    return exports.INTENT_PERMISSION_MAP[intent];
}
