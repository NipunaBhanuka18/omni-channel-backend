import { TenantContext } from "../../shared/types/tenant-context";
import { AgentActionResponse } from "../../shared/types/agent-action";
export interface TenantConfig {
    tenantId: string;
    name: string;
    status: "active" | "suspended" | "inactive";
    allowedChannels: TenantContext["channel"][];
    defaultAgent: string;
}
export interface RoutingDecisionData {
    targetAgent: string;
    tenantContext: TenantContext;
    routedAt: string;
}
export interface RoutingDecisionResult {
    success: boolean;
    data?: RoutingDecisionData;
    error?: AgentActionResponse["error"];
}
/**
 * Multi-Tenant Registry Store
 * Configured so adding a second tenant later is a simple configuration addition without logic changes.
 */
export declare const TENANT_REGISTRY: Record<string, TenantConfig>;
/**
 * Evaluates a TenantContext against tenant configuration and returns a routing decision.
 *
 * @param context Resolved TenantContext
 * @returns RoutingDecisionResult with targetAgent handoff boundary or error
 */
export declare function routeRequest(context: TenantContext): RoutingDecisionResult;
