import { AgentActionResponse } from "../../shared/types/agent-action";
export interface HttpRequestPayload {
    headers: Record<string, string | undefined>;
    body?: Record<string, any>;
}
/**
 * Handles incoming API request payload through the Tenant Resolver, Tenant Runtime Router, and Main Agent pipeline.
 *
 * @param request Incoming HTTP request containing headers and optional body
 * @returns AgentActionResponse shape
 */
export declare function handleTenantRequest(request: HttpRequestPayload): Promise<AgentActionResponse>;
