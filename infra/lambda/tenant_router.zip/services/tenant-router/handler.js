"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleTenantRequest = handleTenantRequest;
const resolver_1 = require("../tenant-resolver/resolver");
const router_1 = require("./router");
const handler_1 = require("../../agents/main-agent/handler");
/**
 * Handles incoming API request payload through the Tenant Resolver, Tenant Runtime Router, and Main Agent pipeline.
 *
 * @param request Incoming HTTP request containing headers and optional body
 * @returns AgentActionResponse shape
 */
async function handleTenantRequest(request) {
    // Step 1: Resolve Tenant Context from headers
    const resolverResult = (0, resolver_1.resolveTenantContext)(request.headers);
    if (!resolverResult.success || !resolverResult.context) {
        return {
            success: false,
            error: resolverResult.error || {
                code: "INTERNAL_ERROR",
                message: "Tenant resolution failed without error details",
                retryable: false,
            },
        };
    }
    // Step 2: Route request using resolved TenantContext
    const routerResult = (0, router_1.routeRequest)(resolverResult.context);
    if (!routerResult.success || !routerResult.data) {
        return {
            success: false,
            error: routerResult.error || {
                code: "ROUTING_FAILED",
                message: "Tenant routing failed without error details",
                retryable: false,
            },
        };
    }
    // Step 3: Validate required intent field from body (no fallback default)
    const intent = request.body?.intent;
    if (!intent || typeof intent !== "string" || intent.trim() === "") {
        return {
            success: false,
            error: {
                code: "BAD_REQUEST",
                message: "Missing required request body field: 'intent'",
                retryable: false,
                details: { requiredField: "intent" },
            },
        };
    }
    const params = request.body?.params || {};
    // Step 4: Invoke Main Agent handler (if targetAgent is main-agent)
    if (routerResult.data.targetAgent === "main-agent") {
        return await (0, handler_1.handler)({
            context: routerResult.data.tenantContext,
            intent: intent.trim(),
            params: params,
        });
    }
    // Fallback for other target agents if added in future
    return {
        success: true,
        data: routerResult.data,
    };
}
