"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler_1 = require("./handler");
/**
 * AWS Lambda Handler Adapter
 * Translates APIGatewayProxyEvent to handleTenantRequest payload and formats response into APIGatewayProxyResult.
 */
const handler = async (event) => {
    try {
        let body = {};
        if (event.body) {
            body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
        }
        // Normalize incoming headers to lowercase keys for consistent lookup
        const rawHeaders = event.headers || {};
        const normalizedHeaders = {};
        for (const key of Object.keys(rawHeaders)) {
            normalizedHeaders[key.toLowerCase()] = rawHeaders[key];
            // Keep original case as fallback
            normalizedHeaders[key] = rawHeaders[key];
        }
        const requestPayload = {
            headers: normalizedHeaders,
            body: body,
        };
        const response = await (0, handler_1.handleTenantRequest)(requestPayload);
        let statusCode = 200;
        if (!response.success) {
            if (response.error?.code === "UNAUTHORIZED") {
                statusCode = 401;
            }
            else if (response.error?.code === "FORBIDDEN") {
                statusCode = 403;
            }
            else if (response.error?.code === "BAD_REQUEST") {
                statusCode = 400;
            }
            else {
                statusCode = 400;
            }
        }
        return {
            statusCode: statusCode,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify(response),
        };
    }
    catch (error) {
        console.error("[LambdaAdapter] Fatal execution error:", error);
        return {
            statusCode: 500,
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                success: false,
                error: {
                    code: "INTERNAL_ERROR",
                    message: "Unhandled Lambda execution error",
                    retryable: false,
                    details: { message: error?.message || String(error) },
                },
            }),
        };
    }
};
exports.handler = handler;
