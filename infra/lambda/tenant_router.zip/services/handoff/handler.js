"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleHandoffApi = handleHandoffApi;
const presence_manager_1 = require("./presence-manager");
const escalation_engine_1 = require("./escalation-engine");
/**
 * REST/WebSocket Ingress Handler for Presence and Handoff Operations (Member 1 Integration).
 */
async function handleHandoffApi(request) {
    const { action, tenantId } = request;
    if (!tenantId) {
        return {
            success: false,
            error: {
                code: "BAD_REQUEST",
                message: "Missing required field: 'tenantId'",
                retryable: false,
            },
        };
    }
    try {
        switch (action) {
            case "presence_online": {
                if (!request.agentId) {
                    return { success: false, error: { code: "BAD_REQUEST", message: "Missing agentId", retryable: false } };
                }
                const record = await (0, presence_manager_1.setAgentPresence)(tenantId, request.agentId, "AVAILABLE", request.connectionId);
                return { success: true, data: record };
            }
            case "presence_offline": {
                if (!request.agentId) {
                    return { success: false, error: { code: "BAD_REQUEST", message: "Missing agentId", retryable: false } };
                }
                const record = await (0, presence_manager_1.setAgentPresence)(tenantId, request.agentId, "OFFLINE");
                return { success: true, data: record };
            }
            case "presence_status": {
                if (!request.agentId) {
                    return { success: false, error: { code: "BAD_REQUEST", message: "Missing agentId", retryable: false } };
                }
                const record = await (0, presence_manager_1.getAgentPresence)(tenantId, request.agentId);
                return { success: true, data: record || { status: "OFFLINE", activeChats: 0 } };
            }
            case "request_handoff": {
                if (!request.sessionId) {
                    return { success: false, error: { code: "BAD_REQUEST", message: "Missing sessionId", retryable: false } };
                }
                const result = await (0, escalation_engine_1.requestHumanHandoff)({
                    tenantId,
                    sessionId: request.sessionId,
                    customerName: request.customerName,
                    issueSummary: request.issueSummary,
                });
                return { success: true, data: result };
            }
            case "resolve_session": {
                if (!request.sessionId || !request.agentId) {
                    return { success: false, error: { code: "BAD_REQUEST", message: "Missing sessionId or agentId", retryable: false } };
                }
                const result = await (0, escalation_engine_1.resolveChatSession)({
                    tenantId,
                    sessionId: request.sessionId,
                    agentId: request.agentId,
                });
                return { success: true, data: result };
            }
            case "session_status": {
                if (!request.sessionId) {
                    return { success: false, error: { code: "BAD_REQUEST", message: "Missing sessionId", retryable: false } };
                }
                const session = await (0, escalation_engine_1.getSessionStatus)(request.sessionId);
                return { success: true, data: session };
            }
            default:
                return {
                    success: false,
                    error: {
                        code: "UNSUPPORTED_ACTION",
                        message: `Action '${action}' is not supported by Handoff handler.`,
                        retryable: false,
                    },
                };
        }
    }
    catch (err) {
        console.error("[HandoffHandler] Unhandled error:", err);
        return {
            success: false,
            error: {
                code: "INTERNAL_ERROR",
                message: err?.message || "Internal handoff error",
                retryable: true,
            },
        };
    }
}
