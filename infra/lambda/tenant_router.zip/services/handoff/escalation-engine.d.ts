export interface ChatSessionRecord {
    sessionId: string;
    tenantId: string;
    status: "BOT_ACTIVE" | "WAITING_FOR_HUMAN" | "HUMAN_ACTIVE" | "RESOLVED" | "MISSED_HANDOFF";
    assignedAgentId?: string;
    customerName?: string;
    issueSummary?: string;
    createdAt: string;
    updatedAt: string;
}
export interface HandoffResult {
    success: boolean;
    assigned: boolean;
    status: ChatSessionRecord["status"];
    agentId?: string;
    message: string;
    sessionId: string;
}
/**
 * Handles incoming escalation requests when a customer requests a human assistant.
 */
export declare function requestHumanHandoff(params: {
    tenantId: string;
    sessionId: string;
    customerName?: string;
    issueSummary?: string;
}): Promise<HandoffResult>;
/**
 * Resolves an active chat session and decrements the agent's workload.
 */
export declare function resolveChatSession(params: {
    tenantId: string;
    sessionId: string;
    agentId: string;
}): Promise<{
    success: boolean;
    status: string;
}>;
/**
 * Helper to fetch session status.
 */
export declare function getSessionStatus(sessionId: string): Promise<ChatSessionRecord | null>;
