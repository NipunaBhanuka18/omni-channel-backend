"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setAgentPresence = setAgentPresence;
exports.getAgentPresence = getAgentPresence;
exports.findAvailableAgent = findAvailableAgent;
exports.adjustActiveChats = adjustActiveChats;
const dynamo_client_1 = require("../../agents/utils/dynamo-client");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
/**
 * In-memory presence registry fallback for local development and offline unit tests.
 */
const MEMORY_PRESENCE_STORE = new Map();
function getPresenceKey(tenantId, agentId) {
    return `${tenantId}#${agentId}`;
}
/**
 * Updates an agent's presence status (e.g., clicking 'Go Online' or 'Go Offline').
 */
async function setAgentPresence(tenantId, agentId, status, connectionId) {
    const key = getPresenceKey(tenantId, agentId);
    const existing = MEMORY_PRESENCE_STORE.get(key);
    const currentActiveChats = existing?.activeChats || 0;
    const record = {
        tenantId,
        agentId,
        status,
        activeChats: status === "OFFLINE" ? 0 : currentActiveChats,
        connectionId: connectionId || existing?.connectionId,
        lastHeartbeat: new Date().toISOString(),
    };
    // Update memory store
    MEMORY_PRESENCE_STORE.set(key, record);
    // Attempt to persist to DynamoDB
    try {
        await dynamo_client_1.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: "omni-channel-agent-presence",
            Item: record,
        }));
    }
    catch (err) {
        console.warn(`[PresenceManager] DynamoDB update failed (${err?.message || err}). Using in-memory fallback.`);
    }
    console.log(`[PresenceManager] Agent '${agentId}' for tenant '${tenantId}' status set to '${status}'`);
    return record;
}
/**
 * Retrieves the current presence status of a human agent.
 */
async function getAgentPresence(tenantId, agentId) {
    try {
        const result = await dynamo_client_1.docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: "omni-channel-agent-presence",
            Key: { tenantId, agentId },
        }));
        if (result.Item) {
            return result.Item;
        }
    }
    catch (err) {
        console.warn(`[PresenceManager] DynamoDB get failed (${err?.message || err}). Checking in-memory store.`);
    }
    return MEMORY_PRESENCE_STORE.get(getPresenceKey(tenantId, agentId)) || null;
}
/**
 * Finds the best available online agent for a tenant (lowest active chat count).
 */
async function findAvailableAgent(tenantId) {
    let candidates = [];
    try {
        // Query DynamoDB for agents in this tenant
        const result = await dynamo_client_1.docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: "omni-channel-agent-presence",
            KeyConditionExpression: "tenantId = :tid",
            ExpressionAttributeValues: {
                ":tid": tenantId,
            },
        }));
        if (result.Items && result.Items.length > 0) {
            candidates = result.Items.filter((a) => a.status === "AVAILABLE");
        }
    }
    catch (err) {
        console.warn(`[PresenceManager] DynamoDB query failed (${err?.message || err}). Checking in-memory store.`);
    }
    if (candidates.length === 0) {
        // Check in-memory store
        for (const record of MEMORY_PRESENCE_STORE.values()) {
            if (record.tenantId === tenantId && record.status === "AVAILABLE") {
                candidates.push(record);
            }
        }
    }
    if (candidates.length === 0) {
        return null;
    }
    // Sort by lowest activeChats
    candidates.sort((a, b) => a.activeChats - b.activeChats);
    return candidates[0];
}
/**
 * Adjusts an agent's active chat count (e.g. +1 on assignment, -1 on resolution).
 */
async function adjustActiveChats(tenantId, agentId, delta) {
    const current = await getAgentPresence(tenantId, agentId);
    const newCount = Math.max(0, (current?.activeChats || 0) + delta);
    if (current) {
        current.activeChats = newCount;
        current.lastHeartbeat = new Date().toISOString();
        MEMORY_PRESENCE_STORE.set(getPresenceKey(tenantId, agentId), current);
    }
    try {
        await dynamo_client_1.docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: "omni-channel-agent-presence",
            Key: { tenantId, agentId },
            UpdateExpression: "SET activeChats = :ac, lastHeartbeat = :lh",
            ExpressionAttributeValues: {
                ":ac": newCount,
                ":lh": new Date().toISOString(),
            },
        }));
    }
    catch (err) {
        console.warn(`[PresenceManager] DynamoDB count update failed (${err?.message || err}).`);
    }
    return newCount;
}
