export interface AgentPresenceRecord {
    tenantId: string;
    agentId: string;
    status: "AVAILABLE" | "OFFLINE" | "BUSY";
    activeChats: number;
    connectionId?: string;
    lastHeartbeat: string;
}
/**
 * Updates an agent's presence status (e.g., clicking 'Go Online' or 'Go Offline').
 */
export declare function setAgentPresence(tenantId: string, agentId: string, status: "AVAILABLE" | "OFFLINE" | "BUSY", connectionId?: string): Promise<AgentPresenceRecord>;
/**
 * Retrieves the current presence status of a human agent.
 */
export declare function getAgentPresence(tenantId: string, agentId: string): Promise<AgentPresenceRecord | null>;
/**
 * Finds the best available online agent for a tenant (lowest active chat count).
 */
export declare function findAvailableAgent(tenantId: string): Promise<AgentPresenceRecord | null>;
/**
 * Adjusts an agent's active chat count (e.g. +1 on assignment, -1 on resolution).
 */
export declare function adjustActiveChats(tenantId: string, agentId: string, delta: number): Promise<number>;
