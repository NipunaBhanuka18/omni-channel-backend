"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestHumanHandoff = requestHumanHandoff;
exports.resolveChatSession = resolveChatSession;
exports.getSessionStatus = getSessionStatus;
const presence_manager_1 = require("./presence-manager");
const dynamo_client_1 = require("../../agents/utils/dynamo-client");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const crypto_1 = require("crypto");
// In-memory fallback session store for local offline testing
const MEMORY_SESSION_STORE = new Map();
const MEMORY_MISSED_HANDOFFS = [];
/**
 * Handles incoming escalation requests when a customer requests a human assistant.
 */
async function requestHumanHandoff(params) {
    const { tenantId, sessionId, customerName = "Guest Customer", issueSummary = "Live assistance requested" } = params;
    console.log(`[EscalationEngine] Received handoff request for session '${sessionId}' in tenant '${tenantId}'`);
    // Step 1: Find best available human agent
    const availableAgent = await (0, presence_manager_1.findAvailableAgent)(tenantId);
    const now = new Date().toISOString();
    if (availableAgent) {
        // Agent is available! Assign session and increment workload
        await (0, presence_manager_1.adjustActiveChats)(tenantId, availableAgent.agentId, 1);
        const sessionRecord = {
            sessionId,
            tenantId,
            status: "HUMAN_ACTIVE",
            assignedAgentId: availableAgent.agentId,
            customerName,
            issueSummary,
            createdAt: now,
            updatedAt: now,
        };
        MEMORY_SESSION_STORE.set(sessionId, sessionRecord);
        try {
            await dynamo_client_1.docClient.send(new lib_dynamodb_1.PutCommand({
                TableName: "omni-channel-chat-sessions",
                Item: sessionRecord,
            }));
        }
        catch (err) {
            console.warn(`[EscalationEngine] Failed to save session to DynamoDB (${err?.message || err}).`);
        }
        console.log(`[EscalationEngine] ✅ Assigned session '${sessionId}' to human agent '${availableAgent.agentId}'`);
        return {
            success: true,
            assigned: true,
            status: "HUMAN_ACTIVE",
            agentId: availableAgent.agentId,
            message: `You are now connected with human agent ${availableAgent.agentId}.`,
            sessionId,
        };
    }
    // No agent is online -> trigger Missed Handoff flow
    console.warn(`[EscalationEngine] ⚠️ No live agents online for tenant '${tenantId}'. Recording missed handoff.`);
    const missedRecord = {
        tenantId,
        missedId: `missed-${(0, crypto_1.randomUUID)()}`,
        sessionId,
        customerName,
        issueSummary,
        timestamp: now,
    };
    MEMORY_MISSED_HANDOFFS.push(missedRecord);
    const sessionRecord = {
        sessionId,
        tenantId,
        status: "MISSED_HANDOFF",
        customerName,
        issueSummary,
        createdAt: now,
        updatedAt: now,
    };
    MEMORY_SESSION_STORE.set(sessionId, sessionRecord);
    try {
        await dynamo_client_1.docClient.send(new lib_dynamodb_1.PutCommand({
            TableName: "omni-channel-missed-handoffs",
            Item: missedRecord,
        }));
    }
    catch (err) {
        console.warn(`[EscalationEngine] Failed saving missed handoff to DynamoDB (${err?.message || err}).`);
    }
    return {
        success: true,
        assigned: false,
        status: "MISSED_HANDOFF",
        message: "All our human agents are currently offline. A support ticket has been created and our team will follow up.",
        sessionId,
    };
}
/**
 * Resolves an active chat session and decrements the agent's workload.
 */
async function resolveChatSession(params) {
    const { tenantId, sessionId, agentId } = params;
    // Decrement agent's active chat count
    await (0, presence_manager_1.adjustActiveChats)(tenantId, agentId, -1);
    const existing = MEMORY_SESSION_STORE.get(sessionId);
    if (existing) {
        existing.status = "RESOLVED";
        existing.updatedAt = new Date().toISOString();
    }
    try {
        await dynamo_client_1.docClient.send(new lib_dynamodb_1.UpdateCommand({
            TableName: "omni-channel-chat-sessions",
            Key: { sessionId },
            UpdateExpression: "SET #st = :st, updatedAt = :u",
            ExpressionAttributeNames: { "#st": "status" },
            ExpressionAttributeValues: {
                ":st": "RESOLVED",
                ":u": new Date().toISOString(),
            },
        }));
    }
    catch (err) {
        console.warn(`[EscalationEngine] Failed updating session in DynamoDB (${err?.message || err}).`);
    }
    console.log(`[EscalationEngine] ✅ Chat session '${sessionId}' resolved by agent '${agentId}'`);
    return {
        success: true,
        status: "RESOLVED",
    };
}
/**
 * Helper to fetch session status.
 */
async function getSessionStatus(sessionId) {
    try {
        const result = await dynamo_client_1.docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: "omni-channel-chat-sessions",
            Key: { sessionId },
        }));
        if (result.Item) {
            return result.Item;
        }
    }
    catch (err) {
        // fallback
    }
    return MEMORY_SESSION_STORE.get(sessionId) || null;
}
