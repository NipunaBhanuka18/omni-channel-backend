import { AgentActionResponse } from "../../shared/types/agent-action";
export interface HandoffApiRequest {
    action: "presence_online" | "presence_offline" | "presence_status" | "request_handoff" | "resolve_session" | "session_status";
    tenantId: string;
    agentId?: string;
    sessionId?: string;
    connectionId?: string;
    customerName?: string;
    issueSummary?: string;
}
/**
 * REST/WebSocket Ingress Handler for Presence and Handoff Operations (Member 1 Integration).
 */
export declare function handleHandoffApi(request: HandoffApiRequest): Promise<AgentActionResponse>;
