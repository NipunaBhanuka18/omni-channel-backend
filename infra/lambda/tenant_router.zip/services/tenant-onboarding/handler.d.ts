export interface OnboardCompanyInput {
    companyName: string;
    adminEmail: string;
    tenantId?: string;
}
export interface OnboardCompanyOutput {
    success: boolean;
    tenantId: string;
    adminEmail: string;
    s3Prefix: string;
    status: string;
}
/**
 * Handles the automated onboarding process for a new company tenant.
 * Provisions tenant storage paths, database partitioning records, and default configurations.
 */
export declare function handleCompanyOnboarding(input: OnboardCompanyInput): Promise<OnboardCompanyOutput>;
