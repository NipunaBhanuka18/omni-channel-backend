"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleCompanyOnboarding = handleCompanyOnboarding;
const dynamo_client_1 = require("../../agents/utils/dynamo-client");
/**
 * Handles the automated onboarding process for a new company tenant.
 * Provisions tenant storage paths, database partitioning records, and default configurations.
 */
async function handleCompanyOnboarding(input) {
    const { companyName, adminEmail } = input;
    if (!companyName || !adminEmail) {
        throw new Error("BAD_REQUEST: companyName and adminEmail are required for onboarding");
    }
    // Generate standardized Tenant ID if omitted
    const tenantId = input.tenantId || `TEN-${Math.floor(1000 + Math.random() * 9000)}`;
    // Construct temporary onboarding context
    const onboardingContext = {
        tenantId,
        userId: "system-onboarding",
        role: "admin",
        permissions: ["billing:read", "usage:read", "faults:create"],
        channel: "web",
        sessionId: `sess-onboarding-${tenantId}`,
        conversationId: `conv-onboarding-${tenantId}`,
    };
    // 1. Register Tenant Metadata Record
    await (0, dynamo_client_1.putTenantItem)("omni-channel-tenants", onboardingContext, {
        SK: "METADATA",
        companyName,
        adminEmail,
        status: "ACTIVE",
        createdAt: new Date().toISOString(),
    });
    // 2. Initialize Default Agent Configuration for the Tenant
    await (0, dynamo_client_1.putTenantItem)("omni-channel-agents", onboardingContext, {
        SK: "AGENT#DEFAULT",
        agentName: `${companyName} Main Agent`,
        status: "CONFIGURED",
        enabledTools: ["billing", "support", "usage"],
        createdAt: new Date().toISOString(),
    });
    const s3Prefix = `tenants/${tenantId}/`;
    return {
        success: true,
        tenantId,
        adminEmail,
        s3Prefix,
        status: "PROVISIONED",
    };
}
