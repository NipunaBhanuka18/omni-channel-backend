export interface TenantContext {
    tenantId: string;
    userId: string;
    role: "staff" | "admin";
    permissions: string[];
    channel: "web" | "whatsapp" | "sms" | "messenger";
    sessionId: string;
    conversationId: string;
}
