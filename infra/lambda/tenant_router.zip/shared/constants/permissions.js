"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PERMISSIONS = void 0;
exports.PERMISSIONS = {
    BILLING_READ: "billing:read",
    BILLING_PURCHASE: "billing:purchase",
    USAGE_READ: "usage:read",
    FAULTS_READ: "faults:read",
    FAULTS_CREATE: "faults:create",
};
