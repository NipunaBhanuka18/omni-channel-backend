export declare const PERMISSIONS: {
    readonly BILLING_READ: "billing:read";
    readonly BILLING_PURCHASE: "billing:purchase";
    readonly USAGE_READ: "usage:read";
    readonly FAULTS_READ: "faults:read";
    readonly FAULTS_CREATE: "faults:create";
};
